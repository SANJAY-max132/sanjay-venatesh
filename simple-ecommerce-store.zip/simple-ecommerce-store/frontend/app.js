// Load and render products from API
async function fetchProducts() {
  try {
    const res = await fetch('/api/products');
    const products = await res.json();

    const list = document.getElementById('product-list');
    list.innerHTML = products.map(product => `
      <div class="product">
        <img src="${product.image}" alt="${product.name}">
        <h4>${product.name}</h4>
        <p>$${product.price}</p>
        <button onclick="addToCart(${product.id}, '${product.name}', ${product.price})">Add to Cart</button>
      </div>
    `).join('');
  } catch (err) {
    console.error('Error loading products:', err);
  }
}

// Add product to cart in localStorage
function addToCart(id, name, price) {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const existing = cart.find(item => item.id === id);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ id, name, price, qty: 1 });
  }
  localStorage.setItem('cart', JSON.stringify(cart));
  alert(`${name} added to cart!`);
}

fetchProducts();
document.getElementById('add-form').addEventListener('submit', async function (e) {
  e.preventDefault();

  const name = document.getElementById('name').value;
  const price = parseFloat(document.getElementById('price').value);
  const image = document.getElementById('image').value;

  try {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, price, image })
    });

    if (res.ok) {
      alert("Product added!");
      fetchProducts(); // reload list
      e.target.reset(); // clear form
    } else {
      alert("Failed to add product");
    }
  } catch (err) {
    console.error(err);
  }
});
// Admin login
document.getElementById('admin-login').addEventListener('submit', function (e) {
  e.preventDefault();
  const username = document.getElementById('admin-username').value;
  const password = document.getElementById('admin-password').value;

  if (username === 'admin' && password === 'admin123') {
    localStorage.setItem('isAdmin', 'true');
    alert('Logged in as Admin!');
    showAdminForm();
  } else {
    alert('Invalid credentials');
  }
});

function logout() {
  localStorage.removeItem('isAdmin');
  showAdminForm();
}

function showAdminForm() {
  const isAdmin = localStorage.getItem('isAdmin') === 'true';
  document.getElementById('add-form').style.display = isAdmin ? 'block' : 'none';
  document.getElementById('logout-btn').style.display = isAdmin ? 'inline' : 'none';
}

// Call on page load
showAdminForm();
