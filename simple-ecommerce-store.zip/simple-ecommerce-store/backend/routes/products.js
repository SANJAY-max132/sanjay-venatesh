const express = require('express');
const router = express.Router();
const db = require('../db');

// Get all products
router.get('/', (req, res) => {
  db.query('SELECT * FROM products', (err, results) => {
    if (err) {
      console.error('Query Error:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json(results);
  });
});

module.exports = router;
// Add this below the GET route
router.post('/', (req, res) => {
  const { name, price, image } = req.body;

  if (!name || !price || !image) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  const sql = 'INSERT INTO products (name, price, image) VALUES (?, ?, ?)';
  db.query(sql, [name, price, image], (err, result) => {
    if (err) {
      console.error('Insert Error:', err);
      return res.status(500).json({ error: 'Database insert error' });
    }
    res.status(201).json({ message: 'Product added', id: result.insertId });
  });
});
// Search products by name
router.get('/search', (req, res) => {
  const searchTerm = req.query.q;
  const sql = `SELECT * FROM products WHERE name LIKE ?`;

  db.query(sql, [`%${searchTerm}%`], (err, results) => {
    if (err) {
      console.error('Search error:', err);
      return res.status(500).json({ error: 'Search failed' });
    }
    res.json(results);
  });
});
