const express = require('express');
const router = express.Router();
const db = require('../db');

// Place order
router.post('/', (req, res) => {
  const { userId, items } = req.body;
  const total = items.reduce((sum, item) => sum + item.price * item.qty, 0);

  db.query('INSERT INTO orders (user_id, total) VALUES (?, ?)', [userId, total], (err, result) => {
    if (err) return res.status(500).json({ error: 'Order error' });

    const orderId = result.insertId;
    const values = items.map(item => [orderId, item.id, item.qty]);

    db.query('INSERT INTO order_items (order_id, product_id, quantity) VALUES ?', [values], (err) => {
      if (err) return res.status(500).json({ error: 'Order item error' });
      res.json({ message: 'Order placed successfully' });
    });
  });
});

module.exports = router;
// Get orders by user ID
router.get('/user/:userId', (req, res) => {
  const userId = req.params.userId;

  const query = `
    SELECT o.id, o.total, o.created_at,
           p.name, oi.quantity
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON p.id = oi.product_id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
  `;

  db.query(query, [userId], (err, results) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch orders' });

    const grouped = {};
    results.forEach(row => {
      if (!grouped[row.id]) {
        grouped[row.id] = {
          id: row.id,
          total: row.total,
          created_at: row.created_at,
          items: []
        };
      }
      grouped[row.id].items.push({ name: row.name, quantity: row.quantity });
    });

    res.json(Object.values(grouped));
  });
});
// Get all orders (admin)
router.get('/all', (req, res) => {
  const query = `
    SELECT o.id, o.total, o.created_at, o.user_id,
           p.name, oi.quantity
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON p.id = oi.product_id
    ORDER BY o.created_at DESC
  `;

  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch all orders' });

    const grouped = {};
    results.forEach(row => {
      if (!grouped[row.id]) {
        grouped[row.id] = {
          id: row.id,
          total: row.total,
          created_at: row.created_at,
          user_id: row.user_id,
          items: []
        };
      }
      grouped[row.id].items.push({ name: row.name, quantity: row.quantity });
    });

    res.json(Object.values(grouped));
  });
});
