const express = require('express');
const cors = require('cors');
const path = require('path');
const productRoutes = require('./routes/products');
const authRoutes = require('./routes/auth');
const orderRoutes = require('./routes/orders');
const app = express();

// Add these
app.use('/api/auth', authRoutes);
app.use('/api/order', orderRoutes);
app.use(express.static('public'));

app.use(cors());
app.use(express.json());

// Serve frontend files
app.use(express.static(path.join(__dirname, '../frontend')));

app.use('/api/products', productRoutes);

app.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});